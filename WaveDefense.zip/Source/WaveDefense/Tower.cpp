// Fill out your copyright notice in the Description page of Project Settings.

#include "Tower.h"
#include "Components/BoxComponent.h"
#include "Components/StaticMeshComponent.h"
#include "WaveDefenseGameModeBase.h"

// Sets default values
ATower::ATower()
{
	PrimaryActorTick.bCanEverTick = false;

	if (!RootComponent)
	{
		RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("ProjectileBase"));
	}
	//������Ʈ
	TowerCollision = CreateDefaultSubobject<UBoxComponent>(TEXT("TowerCollision"));
	TowerCollision->SetupAttachment(RootComponent);
		
	//������Ʈ
	TowerMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("TowerMesh"));
	TowerMesh->SetupAttachment(RootComponent);

}

// Called when the game starts or when spawned
void ATower::BeginPlay()
{
	Super::BeginPlay();
	SetInitialStat();
	
}
void ATower::SetInitialStat()
{
	CurrentDurability = MaxDurability;
}


void ATower::CalculateDurability_Implementation(float Amount)
{
	CurrentDurability += Amount;
	CalculateDestroy();
}

void ATower::CalculateDestroy()
{
	if (CurrentDurability <= 0)
	{
		Destroy();
	}
}

void ATower::Damaged_Implementation(float Amount)
{
	CalculateDurability(-Amount);
}

void ATower::Destroy_Implementation()
{
	AWaveDefenseGameModeBase* MyGameMode = (AWaveDefenseGameModeBase*)GetWorld()->GetAuthGameMode();
	if (MyGameMode)
	{
		MyGameMode->TowerDestroyed();
	}
	this->SetActorHiddenInGame(true);
}
