// Fill out your copyright notice in the Description page of Project Settings.

#include "EnemyCharacter.h"
#include "Kismet/KismetMathLibrary.h"
#include "Components/ArrowComponent.h"
#include "Projectile.h"
#include "WaveDefenseGameModeBase.h"



AEnemyCharacter::AEnemyCharacter()
{
	SetInitialStat();
}


void AEnemyCharacter::BeginPlay()
{
	Super::BeginPlay();
	MyGameMode = (AWaveDefenseGameModeBase*)GetWorld()->GetAuthGameMode();
	
}


void AEnemyCharacter::SetInitialStat()
{
	//MaxHealth = MaxHealth + (MaxHealth * MyGameMode->GetCurrentWave());
	Super::SetInitialStat();
}


void AEnemyCharacter::ToggleCanAttack()
{
	CanAttack = !CanAttack;
}


void AEnemyCharacter::SetTagetToAttack(AActor * TargetActor)
{
	TargetToAttack = TargetActor;
}


AActor * AEnemyCharacter::GetTargetToAttack() const
{
	return TargetToAttack;
} 


void AEnemyCharacter::Attack_Implementation()
{	
	//Ÿ���� ���� ���� ��ȯ
	FRotator DesireRotation =
		UKismetMathLibrary::FindLookAtRotation(this->GetActorLocation(), FVector(TargetToAttack->GetActorLocation().X, TargetToAttack->GetActorLocation().Y, this->GetActorLocation().Z));
	this->GetController()->SetControlRotation(DesireRotation);
	this->SetActorRotation(DesireRotation);

	//���ݴ��ð��� return
	if (CanAttack == false)
	{
		return;
	}

	//������Ÿ�� �߻縦 �õ�.
	if (EnemyProjectile)
	{
		if (AttackPoint != nullptr)
		{
			UWorld* const World = GetWorld();
			if (World)
			{
				FVector SpawnLocation = AttackPoint->GetComponentLocation();
				FRotator SpawnRotation = AttackPoint->GetComponentRotation();

				FActorSpawnParameters SpawnParams;
				SpawnParams.Owner = this;
				SpawnParams.Instigator = Instigator;

				// �߻�ü ����.
				AProjectile* Projectile = World->SpawnActor<AProjectile>(EnemyProjectile, SpawnLocation, SpawnRotation, SpawnParams);

				CanAttack = false;
				GetWorldTimerManager().SetTimer(CanAttackTimerHandle, this, &AEnemyCharacter::ToggleCanAttack, AttackRate, false);				
			}
		}

	}
}


void AEnemyCharacter::Death_Implementation()
{
	Super::Death_Implementation();	

	if (MyGameMode)
	{
		MyGameMode->EnemyDead(this);
	}

	//AI �ߴ�
	this->DetachFromControllerPendingDestroy();
	
	//2.5���� �� ���� �ı�
	FTimerHandle DestroyTimerHandle;
	GetWorldTimerManager().SetTimer(DestroyTimerHandle, this, &AEnemyCharacter::DestroyDeadbody, 2.5f, false);
	

}


void AEnemyCharacter::DestroyDeadbody()
{
	Destroy();
}