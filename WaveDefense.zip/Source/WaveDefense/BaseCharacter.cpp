	// Fill out your copyright notice in the Description page of Project Settings.

#include "BaseCharacter.h"
#include "Components/ArrowComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/MeshComponent.h"





ABaseCharacter::ABaseCharacter()
{ 	
	PrimaryActorTick.bCanEverTick = false;

	//������Ʈ
	AttackPoint = CreateDefaultSubobject<UArrowComponent>(TEXT("AttackPoint"));
	AttackPoint->SetupAttachment(RootComponent);

	CharacterDirection = this->FindComponentByClass<UArrowComponent>();
	CharacterCapsule = this->FindComponentByClass<UCapsuleComponent>();
	CharacterMesh = this->FindComponentByClass<UMeshComponent>();
}


void ABaseCharacter::SetInitialStat()
{
	CurrentHealth = MaxHealth;
	CalculateHealth(0);
}


void ABaseCharacter::CalculateHealth_Implementation(float Amount)
{
	CurrentHealth += Amount;
	if (CurrentHealth > MaxHealth)
	{
		CurrentHealth = MaxHealth;
	}
	CalculateDead();
}


void ABaseCharacter::CalculateDead()
{
	if (CurrentHealth <= 0)
	{	
		Death();
	}
}


void ABaseCharacter::Damaged_Implementation(float Amount)
{
	CalculateHealth(-Amount);
}


void ABaseCharacter::Death_Implementation()
{
	IsDead = true;
	
	//���� ���࿡ ���ذ� ���� �ʵ��� �ݸ��� ä���� ����
	CharacterCapsule->SetCollisionProfileName("DeadPreset");
}


UArrowComponent* ABaseCharacter::GetAttackPoint() const
{
	return AttackPoint;
}


void ABaseCharacter::Attack_Implementation()
{
}


bool ABaseCharacter::GetIsDead() const
{
	return IsDead;
}

