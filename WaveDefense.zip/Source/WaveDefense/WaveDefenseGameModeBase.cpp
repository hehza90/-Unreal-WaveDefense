// Fill out your copyright notice in the Description page of Project Settings.

#include "WaveDefenseGameModeBase.h"
#include "PlayerCharacter.h"
#include "Kismet/GameplayStatics.h"
#include "Blueprint/UserWidget.h"
#include "Tower.h"

void AWaveDefenseGameModeBase::BeginPlay()
{
	StartGame();
}


void AWaveDefenseGameModeBase::StartGame()
{		

	APlayerController* MyController = GetWorld()->GetFirstPlayerController();
	//���콺Ŀ������
	MyController->bShowMouseCursor = false;
	MyController->bEnableClickEvents = false;
	MyController->bEnableMouseOverEvents = false;

	//GetWorldTimerManager().SetTimer(WaveWaitingTimerHandle, this, &AWaveDefenseGameModeBase::Re, 0.5f, false);
	GetWorldTimerManager().SetTimer(WaveWaitingTimerHandle, this, &AWaveDefenseGameModeBase::StartWave, WaveWaitingTime, false);
		

	//��������
	SetWidget(WaveInformation);
	SetWidget(PlayerHealthBar);
	SetWidget(TowerDurabilityBar);
	SetWidget(AmmoInfo);
	SetWidget(ReloadProgressBar);
	SetWidget(ReSpawnInfo);
	SetWidget(QButton);
}


int AWaveDefenseGameModeBase::GetCurrentWave() const
{
	return CurrentWave;
}


int AWaveDefenseGameModeBase::GetScore() const
{
	return Score;
}


void AWaveDefenseGameModeBase::SetMainTower(ATower * TargetTower)
{
	MainTower = TargetTower;
}


ATower* AWaveDefenseGameModeBase::GetMainTower() const
{
	return MainTower;
}


void AWaveDefenseGameModeBase::SetReSpawnPoint(AActor * TargetActor)
{
	ReSpawnPointActor = TargetActor;
}


void AWaveDefenseGameModeBase::SetSpawnPointsHead(AActor * TargetActor)
{
	SpawnPointsHead = TargetActor;
}


AActor * AWaveDefenseGameModeBase::GetSpawnPointsHead() const
{
	return SpawnPointsHead;
}


AActor * AWaveDefenseGameModeBase::GetRandomSpawnPoint() const
{
	TArray<AActor*> SpawnPoints;
	//SpawnPointsHead�� �پ� �ִ� ���͵��� �迭
	SpawnPointsHead->GetAttachedActors(SpawnPoints);	
	
	uint32 SpawnPointIndex = FMath::RandRange(0, SpawnPoints.Num() - 1);

	return SpawnPoints[SpawnPointIndex];
}


void AWaveDefenseGameModeBase::StartWave()
{
	RemainNumber = NumberToSpawn;
	GetWorldTimerManager().SetTimer(EnemySpawnTimerHandle, this, &AWaveDefenseGameModeBase::SpawnEnemy, SpawnDelay, true);
}


void AWaveDefenseGameModeBase::EndWave()
{
	if (IsGameOver == true)
	{
		return;
	}
	CurrentWave++;

	if (CurrentWave<MaxWave)
	{
		//���ð�	
		GetWorldTimerManager().SetTimer(WaveWaitingTimerHandle, this, &AWaveDefenseGameModeBase::StartWave, WaveWaitingTime, false);			
	}
	else
	{
		//Ŭ����
	}
}


void AWaveDefenseGameModeBase::SpawnEnemy()
{
	if (IsGameOver == true)
	{
		return;
	}
	if (SpawnedNumber >= NumberToSpawn)
	{
		GetWorldTimerManager().ClearTimer(EnemySpawnTimerHandle);
		SpawnedNumber = 0;
		return;
	}


	uint32 EnemyIndex = FMath::RandRange(0, EnemyList.Num() - 1);	

	if (EnemyList[EnemyIndex])
	{
		FVector SpawnLocation = FVector(0, 0, 0);
		FRotator SpawnRotation = FRotator(0, 0, 0);

				
		AActor* SpawnPointPointer = GetRandomSpawnPoint();

		//��ġ, ȸ���� ����		
		if (SpawnPointPointer != nullptr)
		{
			SpawnLocation = SpawnPointPointer->GetActorLocation();
			SpawnRotation = SpawnPointPointer->GetActorRotation();

			//������ 
			UWorld* const World = GetWorld();
			if (World)
			{
				FActorSpawnParameters SpawnParams;
				SpawnParams.Owner = this;
				SpawnParams.Instigator = Instigator;
				AEnemyCharacter* NewEnemy = World->SpawnActor<AEnemyCharacter>(EnemyList[EnemyIndex], SpawnLocation, SpawnRotation, SpawnParams);
				SpawnedNumber++;
			}
		}
	}
}


void AWaveDefenseGameModeBase::SetWidget(TSubclassOf<UUserWidget> TargetWidget)
{	
	if (TargetWidget != NULL)
	{
		UUserWidget* TempWidget = CreateWidget<UUserWidget>(GetWorld(), TargetWidget);
		TempWidget->AddToViewport();		
	}
}


void AWaveDefenseGameModeBase::EnemyDead_Implementation(AEnemyCharacter* DeadEnemy)
{
	if (IsGameOver == true)
	{
		return;
	}
	RemainNumber--;
	Score += DeadEnemy->ScorePoint;

	if (RemainNumber <= 0)
	{
		EndWave();
	}
}


void AWaveDefenseGameModeBase::TowerDestroyed()
{	
	GameOver();
}


void AWaveDefenseGameModeBase::PlayerDead()
{	
	SetWidget(ReSpawnInfo);
	GetWorldTimerManager().SetTimer(ReSpawnTimerHandle, this, &AWaveDefenseGameModeBase::ReSpawnPlayer, ReSpawnWaitingTime, false);	
}


void AWaveDefenseGameModeBase::ReSpawnPlayer()
{
	if (IsGameOver == true)
	{
		return;
	}
	
	//�÷��̾ �ִٸ� ����
	APlayerCharacter* Player = Cast<APlayerCharacter>(UGameplayStatics::GetPlayerPawn(GetWorld(), 0));
	if(Player)
	{
		for (int i = 0; i < Player->SpawnedWeapons.Num(); i++)
		{
			if (Player->SpawnedWeapons[i])
			{
				Player->SpawnedWeapons[i]->Destroy();			
			}
		}
		Player->SpawnedWeapons.Empty();
		APlayerController* MyController = GetWorld()->GetFirstPlayerController();
		
		//�÷��̾� ����
		Player->Destroy();
		//��������
		MyController->UnPossess();
	}


	//�÷��̾� ������ Possess
	if (ReSpawnPointActor != nullptr)
	{
		FVector SpawnLocation = FVector(0, 0, 0);
		FRotator SpawnRotation = FRotator(0, 0, 0);

		SpawnLocation = ReSpawnPointActor->GetActorLocation();
		SpawnRotation = ReSpawnPointActor->GetActorRotation();

		//������ 
		UWorld* const World = GetWorld();
		if (World)
		{
			FActorSpawnParameters SpawnParams;
			SpawnParams.Owner = this;
			SpawnParams.Instigator = Instigator;
			if (PlayerBlueprint)
			{
				APlayerCharacter* ReSpawnedPlayer = World->SpawnActor<APlayerCharacter>(PlayerBlueprint, SpawnLocation, SpawnRotation, SpawnParams);
				if (ReSpawnedPlayer)
				{				
					UGameplayStatics::GetPlayerController(GetWorld(), 0)->Possess(ReSpawnedPlayer);
				}
			}			
		}
	}

}


void AWaveDefenseGameModeBase::OpenLevel(FName LevelName)
{
	UGameplayStatics::OpenLevel(GetWorld(), LevelName);
}


void AWaveDefenseGameModeBase::GameOver()
{

	if (IsGameOver==true)
	{
		return;
	}

	IsGameOver = true;
	
	
	SetWidget(GameOverMenu);
	APlayerController* MyController = GetWorld()->GetFirstPlayerController();

	MyController->bShowMouseCursor = true;
	MyController->bEnableClickEvents = true;
	MyController->bEnableMouseOverEvents = true;

	MyController->UnPossess();

}
