// Fill out your copyright notice in the Description page of Project Settings.

#include "Weapon.h"
#include "Projectile.h"
#include "PlayerCharacter.h"
#include "Components/ArrowComponent.h"
#include "Components/SkeletalMeshComponent.h"




AWeapon::AWeapon()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	if (!RootComponent)
	{
		RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("WeaponBase"));

	}
	EquipedMesh = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("WeaponMesh"));
	EquipedMesh->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);

	FirePoint = CreateDefaultSubobject<UArrowComponent>(TEXT("FirePoint"));
	FirePoint->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);

	SetCurrentState(EWeaponState::WS_Idle);

}


void AWeapon::BeginPlay()
{
	Super::BeginPlay();
	SetAmmoFull();
}


void AWeapon::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	Fire();
	CountDownCooldown(DeltaTime);

	if (CurrentAmmo <= 0)
	{
		StartReload();
	}

	if (IsReloading)
	{
		Reloading(DeltaTime);
	}

}


void AWeapon::SetOwnerPlayer(APlayerCharacter * Target)
{
	OwnerPlayer = Target;
}


void AWeapon::SetCurrentState(EWeaponState State)
{
	CurrentState = State;
}


void AWeapon::StartFire()
{
	SetCurrentState(EWeaponState::WS_Shooting);
}


void AWeapon::StopFire()
{
	SetCurrentState(EWeaponState::WS_Idle);
}


void AWeapon::Fire_Implementation()
{
	//���� �������� �ƴҶ�
	if (CurrentState != EWeaponState::WS_Shooting)
	{
		return;
	}

	//������ ��
	if (IsReloading)
	{
		return;
	}

	//�߻� ���ð���
	if (IsCooldown)
	{
		return;
	}

	//������Ÿ�� �߻縦 �õ��մϴ�.
	if (WeaponProjectile)
	{
		if (OwnerPlayer)
		{
			UArrowComponent* SpawnPoint = OwnerPlayer->GetAttackPoint();
			if (SpawnPoint)
			{
				UWorld* const World = GetWorld();
				if (World)
				{
					FVector SpawnLocation = SpawnPoint->GetComponentLocation();
					FRotator SpawnRotation = SpawnPoint->GetComponentRotation();

					FActorSpawnParameters SpawnParams;
					SpawnParams.Owner = this;
					SpawnParams.Instigator = Instigator;

					// �ѱ� ��ġ�� �߻�ü�� ������ŵ�ϴ�.
					AProjectile* SpawnedProjectile = World->SpawnActor<AProjectile>(WeaponProjectile, SpawnLocation, SpawnRotation, SpawnParams);
					CurrentAmmo -= NeedAmmo;
					ResetCooldown();
				}
			}
		}
	}
}


void AWeapon::HideThisWeapon()
{
	EquipedMesh->SetHiddenInGame(true, true);
}


void AWeapon::RevealThisWeapon()
{
	EquipedMesh->SetHiddenInGame(false, true);
}


void AWeapon::CountDownCooldown(float Time)
{
	if (RemainCooldownTime > 0)
	{
		RemainCooldownTime -= Time;
	}
	else
	{
		FinishCooldown();
	}

}


void AWeapon::FinishCooldown()
{
	IsCooldown = false;
}


void AWeapon::ResetCooldown()
{
	IsCooldown = true;
	RemainCooldownTime = Cooldown;
}


void AWeapon::StartReload()
{
	//źâ�� �ִ�ġ �϶� return
	if (CurrentAmmo == MaxAmmo)
	{
		return;
	}

	if (IsReloading)
	{
		return;
	}
	IsReloading = true;

}


void AWeapon::StopReload()
{
	GetWorldTimerManager().ClearTimer(ReloadingTimerHandle);
	IsReloading = false;
	ReloadProgress = 0;
}


void AWeapon::CompleteReload()
{
	SetAmmoFull();
	IsReloading = false;
	ReloadProgress = 0;
}


void AWeapon::SetAmmoFull()
{
	CurrentAmmo = MaxAmmo;
}


void AWeapon::Reloading(float Time)
{
	if (ReloadProgress >= ReloadTime)
	{
		CompleteReload();
	}
	ReloadProgress += Time;
}


