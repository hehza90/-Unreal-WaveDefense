// Fill out your copyright notice in the Description page of Project Settings.

#include "Projectile.h"
#include "Damageable.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "Components/SphereComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Particles/ParticleSystemComponent.h"


AProjectile::AProjectile()
{	
	PrimaryActorTick.bCanEverTick = false;
	if (!RootComponent)
	{
		RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("ProjectileBase"));
	}
	//������Ʈ ����
	ProjectileCollision = CreateDefaultSubobject<USphereComponent>(TEXT("ProjectileCollision"));
	ProjectileCollision->SetupAttachment(RootComponent);

	ProjectileMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("ProjectileMesh"));
	ProjectileMesh->SetupAttachment(RootComponent);

	ParticleSystem = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("ParticleSystem"));
	ParticleSystem->SetupAttachment(RootComponent);
	
	ProjectileMovement = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("ProjectileMovementComponemt"));


	//�浹�� �߻��� �̺�Ʈ ���
	ProjectileCollision->OnComponentBeginOverlap.AddDynamic(this, &AProjectile::OnHit);

}


void AProjectile::OnHit_Implementation(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult &SweepResult)
{	
	//�������� ���� �� �ִ� ������� �������̽��� ���� Ȯ��	
	IDamageable* DamageableActor = Cast<IDamageable>(OtherActor);

	if (DamageableActor != nullptr) 
	{
		//�������� ��
		DamageableActor->Execute_Damaged(OtherActor, Damage);	
	}
	ProjectileCollision->SetActive(false);
	ProjectileMesh->SetHiddenInGame(true);
	ProjectileMesh->SetActive(false);
	ProjectileMovement->SetActive(false);


	ParticleSystem->ActivateSystem();

	//Destroy();
}