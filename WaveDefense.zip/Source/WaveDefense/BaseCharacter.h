// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "Damageable.h"
#include "BaseCharacter.generated.h"

UCLASS()
class WAVEDEFENSE_API ABaseCharacter : public ACharacter, public IDamageable
{
	GENERATED_BODY()

public:
	// Sets default values for this character's properties
	ABaseCharacter();

	

protected:
	//������Ʈ
	UPROPERTY(EditAnywhere, Category = "Character")
		class UArrowComponent* CharacterDirection;

	UPROPERTY(EditAnywhere, Category = "Character")
		class UCapsuleComponent* CharacterCapsule;

	UPROPERTY(EditAnywhere, Category = "Character")
		class UMeshComponent* CharacterMesh;
	
	//������ ������ ��ġ, ����
	UPROPERTY(EditAnywhere, Category = "Character")
		class UArrowComponent* AttackPoint;


protected:
	//Health
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Character", meta = (AllowPrivateAccess = "true"))
		float MaxHealth = 100.0f;

	UPROPERTY(BlueprintReadOnly, VisibleAnywhere, Category = "Character", meta = (AllowPrivateAccess = "true"))
		float CurrentHealth;

	//���� ����
	UPROPERTY(BlueprintReadOnly, VisibleAnywhere, Category = "Character", meta = (AllowPrivateAccess = "true"))
		bool IsDead = false;
		

protected:
	virtual void SetInitialStat();

	//Health ���
	UFUNCTION(BlueprintNativeEvent, Category = "Character")
		void CalculateHealth(float Amount);
	virtual void CalculateHealth_Implementation(float Amount);


	//���� ���
	virtual void CalculateDead();
	

	//Damageable �������̽����� ��� ���� �Լ�
	UFUNCTION(BlueprintNativeEvent, Category = "Interaction")
		void Damaged(float Amount);
	virtual void Damaged_Implementation(float Amount) override;

	//����
	UFUNCTION(BlueprintNativeEvent, Category = "Character")
		void Death();
	virtual void Death_Implementation();

public:
	//������ ������ ��ġ �б�
	UArrowComponent* GetAttackPoint() const;
	

	//����
	UFUNCTION(BlueprintNativeEvent,	BlueprintCallable, Category = "Action")
		void Attack();
	virtual void Attack_Implementation();


	//���� ���� �б�
	UFUNCTION(BlueprintCallable)
		bool GetIsDead() const;	

};
