// Fill out your copyright notice in the Description page of Project Settings.

#include "PlayerCharacter.h"
#include "Weapon.h"
#include "WaveDefenseGameModeBase.h"
#include "Components/InputComponent.h"
#include "Components/ArrowComponent.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/Controller.h"
#include "GameFramework/SpringArmComponent.h"
#include "GameFramework/Character.h"

// Sets default values
APlayerCharacter::APlayerCharacter()
{
	//SpringArm ������Ʈ
	SpringArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraArm"));
	SpringArm->SetupAttachment(RootComponent);
	//ī�޶�
	FollowCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("FollowCamera"));
	FollowCamera->SetupAttachment(SpringArm, USpringArmComponent::SocketName);
	
	
	BaseTurnRate = 45.f;
	BaseLookUpRate = 45.f;

}


void APlayerCharacter::BeginPlay()
{
	Super::BeginPlay();
	SetInitialStat();

	CalculateHealth(0.f);

	//��������Ʈ���� �Ҵ�� WeaponList�� ũ�⸸ŭ SpawnedWeapons�� �Ҵ�
	SpawnedWeapons.SetNum(WeaponList.Num(), false);

	//������ ������� ����
	for (int i = 0; i < WeaponList.Num(); i++)
	{
		SpawnWeapon(WeaponList[i], i);
	}

	//CurrentWeapon �� ù��° ���� ����
	SetCurrentWeapon(1);
}


void APlayerCharacter::SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	check(PlayerInputComponent);
	
	PlayerInputComponent->BindAction("Jump", IE_Pressed, this, &ACharacter::Jump);
	PlayerInputComponent->BindAction("Jump", IE_Released, this, &ACharacter::StopJumping);

	PlayerInputComponent->BindAxis("MoveForward", this, &APlayerCharacter::MoveForward);
	PlayerInputComponent->BindAxis("MoveRight", this, &APlayerCharacter::MoveRight);

	
	PlayerInputComponent->BindAxis("Turn", this, &APlayerCharacter::Turn);	
	PlayerInputComponent->BindAxis("LookUp", this, &APlayerCharacter::LookUp);

	
	PlayerInputComponent->BindAction("Crouch", IE_Pressed, this, &APlayerCharacter::StartCrouch);
	PlayerInputComponent->BindAction("Crouch", IE_Released, this, &APlayerCharacter::StopCrouch);

	PlayerInputComponent->BindAction("Sprint", IE_Pressed, this, &APlayerCharacter::StartSprint);
	PlayerInputComponent->BindAction("Sprint", IE_Released, this, &APlayerCharacter::StopSprint);
		

	PlayerInputComponent->BindAction("Attack", IE_Pressed, this, &APlayerCharacter::Attack);
	PlayerInputComponent->BindAction("Attack", IE_Released, this, &APlayerCharacter::StopAttack);

	PlayerInputComponent->BindAction("Reload", IE_Pressed, this, &APlayerCharacter::StartReload);

	PlayerInputComponent->BindAction("SelectWeaponOne", IE_Pressed, this, &APlayerCharacter::SetCurrentWeapon<1>);	
	PlayerInputComponent->BindAction("SelectWeaponTwo", IE_Pressed, this, &APlayerCharacter::SetCurrentWeapon<2>);	

	PlayerInputComponent->BindAction("UseQSkill", IE_Pressed, this, &APlayerCharacter::UseQSkill);
}


void APlayerCharacter::MoveForward(float Value)
{		
	if (IsSprint && Value < 0.5)
	{
		StopSprint();
	}

	if ((Controller != NULL) && (Value != 0.0f))
	{		
		//���� ã��
		const FRotator Rotation = Controller->GetControlRotation();
		const FRotator YawRotation(0, Rotation.Yaw, 0);

		//���� ����
		const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);
		AddMovementInput(Direction, Value);
	}
}


void APlayerCharacter::MoveRight(float Value)
{
	if (!IsSprint)
	{
		if ((Controller != NULL) && (Value != 0.0f))
		{
			// find out which way is right
			const FRotator Rotation = Controller->GetControlRotation();
			const FRotator YawRotation(0, Rotation.Yaw, 0);

			// get right vector 
			const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::Y);
			// add movement in that direction
			AddMovementInput(Direction, Value);
		}
	}
}


void APlayerCharacter::Turn(float Value)
{	
	if (IsSprint)
		Value *= 0.25f;

	AddControllerYawInput(Value * BaseTurnRate * GetWorld()->GetDeltaSeconds());
}


void APlayerCharacter::LookUp(float Value)
{	
	AddControllerPitchInput(Value * BaseLookUpRate * GetWorld()->GetDeltaSeconds());
}


void APlayerCharacter::StartCrouch()
{
	Crouch();
}


void APlayerCharacter::StopCrouch()
{
	UnCrouch();
}


void APlayerCharacter::StartSprint()
{
	UnCrouch();
	IsSprint = true;
	UpdateMovementSpeed();
}


void APlayerCharacter::StopSprint()
{
	IsSprint = false;
	UpdateMovementSpeed();
}


void APlayerCharacter::SetInitialStat()
{	
	Super::SetInitialStat();	
}


void APlayerCharacter::UpdateMovementSpeed()
{
	if (IsSprint == true)
		GetCharacterMovement()->MaxWalkSpeed = 750.f;
	else
		GetCharacterMovement()->MaxWalkSpeed = 500.f;
}


void APlayerCharacter::Death_Implementation()
{
	Super::Death_Implementation();
	StopAttack();
	StopReload();
	this->DisableInput(Cast<APlayerController>(this->GetController()));	
	//���Ӹ�忡�� �÷��̾ �׾����� ������ �Լ� ����
	AWaveDefenseGameModeBase* MyGameMode;
	MyGameMode = (AWaveDefenseGameModeBase*)GetWorld()->GetAuthGameMode();
	
	
	APlayerController* MyController = GetWorld()->GetFirstPlayerController();		
	//MyController->UnPossess();

		
	MyGameMode->PlayerDead();

}


void APlayerCharacter::SetCurrentWeapon(int Slot)
{
	//0�� �ƴ� 1���� �Է� ����
	//Array�� ũ�⸦ ����� �ʰ�
	if (!(Slot-1 > (SpawnedWeapons.Num() - 1)))
	{
		//�ش� ���Կ� �Ҵ�Ǿ� �ִ���
		if (SpawnedWeapons[Slot-1] != nullptr)
		{
			//CurrenWeapon�� �Ҵ�Ǿ� �ִٸ� nullptr
			if (CurrentWeapon != nullptr)
			{	
				StopReload();
				CurrentWeapon->HideThisWeapon();
				CurrentWeapon = nullptr;
			}
			//���ϴ� ���� �Ҵ�
			CurrentWeapon = SpawnedWeapons[Slot-1];
			CurrentWeapon->RevealThisWeapon();
		}
	}
}


template<int Slot>
void APlayerCharacter::SetCurrentWeapon()
{
	SetCurrentWeapon(Slot);
}


void APlayerCharacter::SpawnWeapon(TSubclassOf<AWeapon> TargetWeapon, uint32 Slot)
{
	//������ ������� ����	
	if (TargetWeapon != NULL)
	{
		UWorld* const World = GetWorld();
		if (World)
		{
			FActorSpawnParameters SpawnParams;
			SpawnParams.Owner = this;
			SpawnParams.Instigator = Instigator;
			AWeapon* TempWeapon = World->SpawnActor<AWeapon>(TargetWeapon, SpawnParams);
			//������ ������ ���� ����
			TempWeapon->SetOwnerPlayer(this);
			//���Կ� �߰�
			SpawnedWeapons[Slot] = TempWeapon;
			//��ü�� �θ��
			//TempWeapon->AttachRootComponentToActor(this);
			//��ü�� �޽��� ���Ͽ� ������ ���� ������			
			TempWeapon->AttachToComponent(CharacterMesh, FAttachmentTransformRules::SnapToTargetNotIncludingScale, FName(TEXT("GunSocket")));			
			//�����
			TempWeapon->HideThisWeapon();
		}
	}
}


void APlayerCharacter::Attack_Implementation()
{
	StopSprint();
	CurrentWeapon->StartFire();
}


void APlayerCharacter::StopAttack()
{
	CurrentWeapon->StopFire();
}


void APlayerCharacter::StartReload()
{
	CurrentWeapon->StartReload();
}


void APlayerCharacter::StopReload()
{
	CurrentWeapon->StopReload();
}


void APlayerCharacter::UseQSkill()
{
	CalculateHealth(50.f);
}