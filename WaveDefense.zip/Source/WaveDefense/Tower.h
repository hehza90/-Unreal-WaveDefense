// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Damageable.h"
#include "Tower.generated.h"

UCLASS()
class WAVEDEFENSE_API ATower : public AActor, public IDamageable
{
	GENERATED_BODY()
	
public:	
	ATower();


protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	

public:
	UPROPERTY(EditAnywhere, Category = "Character")
		class UBoxComponent* TowerCollision;

	UPROPERTY(EditAnywhere, Category = "Character")
		class UStaticMeshComponent* TowerMesh;

protected:
	//������
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Character", meta = (AllowPrivateAccess = "true"))
		float MaxDurability = 10000.0f;

	UPROPERTY(BlueprintReadOnly, VisibleAnywhere, Category = "Character", meta = (AllowPrivateAccess = "true"))
		float CurrentDurability;

	
protected:

	virtual void SetInitialStat();

	//������ ���
	UFUNCTION(BlueprintNativeEvent, Category = "Character")
		void CalculateDurability(float Amount);
	virtual void CalculateDurability_Implementation(float Amount);

	//���� ���
	virtual void CalculateDestroy();


	//Damageable �������̽����� ��� ���� �Լ�
	UFUNCTION(BlueprintNativeEvent, Category = "Interaction")
		void Damaged(float Amount);
	virtual void Damaged_Implementation(float Amount) override;

	//����
	UFUNCTION(BlueprintNativeEvent, Category = "Character")
		void Destroy();
	virtual void Destroy_Implementation();
	
};
